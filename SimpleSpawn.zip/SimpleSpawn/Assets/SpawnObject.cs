using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpawnObject : MonoBehaviour {
	//Array for enemy GameObjects
	public GameObject enemies;
	 public Vector3 center;
	 public Vector3 size;
 
     // Use this for initialization
     void Start () 
     {
		 SpawnCoon();             
     }
 	void Update ()
 	{	
		 //constantly creating new float value, AKA Randomization
		 if(Input.GetKey(KeyCode.Q))
		 {
			 SpawnCoon();
		 }
 	}
	public void SpawnCoon()
	{
		Vector3 pos = center + new Vector3(Random.Range(-size.x / 2,-size.x / 2), Random.Range(-size.y / 2,-size.y / 2),Random.Range(-size.z / 2,-size.z / 2));

		Instantiate(enemies, pos, Quaternion.identity);
	}

	void OnDrawGizmosSelected ()
	{
		
	}
}
     