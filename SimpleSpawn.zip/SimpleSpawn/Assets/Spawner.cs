﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Spawner : MonoBehaviour {
	//Array for enemy GameObjects
	public GameObject[] enemies;

	
     public float spawnTime = 6f;   
	 //Time and Range Controls         // How long between each spawn.
     private Vector3 spawnValues;
	 public float spawnWait;
	 public float spawnMostWait;
	 public float spawnLeastWait;
	 public int startwait;
	 public bool stop;
	 int randEnemy;
 
     // Use this for initialization
     void Start () 
     {
         StartCoroutine(waitSpawner());
     
     }
 	void Update ()
 	{	
		 //constantly creating new float value, AKA Randomization
		 spawnWait = Random.Range (spawnLeastWait, spawnMostWait);
 	}

	IEnumerator waitSpawner()
	{
		yield return new WaitForSeconds(startwait);

		while (!stop)
		{
			//only accessing 0-1 to access enemies. Increase numbers for greater enemy types
			Debug.Log("Hello");
			randEnemy = Random.Range(0,1);
			//Y is kept = to 1, but can be changed if we have jumping raccoons
			Vector3 spawnPosition = new Vector3 (Random.Range (-spawnValues.x, spawnValues.x), 1, Random.Range (-spawnValues.z, spawnValues.z));
			//Here we are simply adding enemies at a static location on the map and spawning them randomly. Adjust location values according to desired raccoon behavior
			Instantiate (enemies[randEnemy], spawnPosition + transform.TransformPoint(0,0,0), gameObject.transform.rotation);

			yield return new WaitForSeconds (spawnWait);
		}
	}
}
     